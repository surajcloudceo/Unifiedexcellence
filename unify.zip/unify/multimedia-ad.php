<?php include_once('header.php'); ?>
     
	<div class="business-banner">           			
        <div class="hvrbox">
            <img src="images/banner-top.jpg" alt="Mountains" class="hvrbox-layer_bottom">
            <div class="hvrbox-layer_top">
                <div class="container">
                    <div class="overlay-text text-left">						
                        <h3>Multimedia & Advertising</h3>
                        <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Multimedia & Advertising</li>
                          </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>	                     
    </div>      
 		
    <div class="bussiness-about-company">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                     <div class="padding-top-large"></div>
                    
                    <div class="about-company-left">
						 <p> To carry on the business of advertising contractors, sub-contractors, agents, designers, advertising, publicity and marketing specialists. </p>                     
                            <p>	To arrange, produce, secure, procure, acquire, retain, purchases, publish, dispose off and distribute advertisement films, TV serials, feature films, and programmes of educational, cultural, devotional, industrial, health entertainment, family welfare, tourism, Government and of other of interest. </p>
                            <div class="promotion-box">		
							<p> 	MULTIMEDIA & ADVERTISING </p>					
							<p>Multimedia advertising is the process of using animation and graphic design to market and sell a product or service. Companies are likely to appeal to a broader audience and increase sales through search engine optimization, extensive keyword research, and strategic linking.</p>
						   </div> 
                           <p>Our uniqueness and success factors are the customer engagement, project management, delivery management and these are possible of our company culture where we provide an environment for every team member to be innovative and a problem solver. We are completely customer focused and determined to satisfy our customers' expectations. </p>
                       </div>
                    
                    
                    
                    
                </div>
                <div class="col-md-3">
                    <div class="padding-top-large"></div>
                    <div class="about-company-right">
                        <div class="right-menubar">
                            <ul>
							  <li class=""><a href="softwaredevelopment.php">Software Development</a></li>
                                <li class=""><a href="consultingservice.php">Consulting Services</a></li>
                                <li class=""><a href="hospitalityservice.php">Hospitality Services</a></li>
                                <li><a href="amcservice.php">Computer AMC Services</a></li>
                                <li><a href="banking.php">Banking & Finance</a></li>
                                <li class="active"><a href="multimedia-ad.php">Multimedia & Advertising</a></li>
                            </ul>
                        </div>                        
                        
                        <div class="padding-top-middle"></div>
                       
                
                    </div>
                </div>
            </div>
        </div>
    </div>
 
    <div class="padding-top-large"></div>
      
  
      
    <div class="business-cta-2x">
		<div class="business-cta-2-content">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<div class="business-cta-left-2">
							<h2>Looking for an excelent business solution ? Your business will change forever with our innovative.</h2>
						</div>
					</div>	
					<div class="col-md-4">
						<div class="business-cta-right-2">
							<a href="contact.php" class=" btn bussiness-btn-larg">Get a Quote <i class="fa fa-angle-right"></i> </a>
						</div>
					</div>	
				</div>	
			</div>	
		</div>	
	</div>
      
	<div class="padding-top-large"></div>
      
    <div class="clients-slider-1x">	
		<div class="container">
			<div class="row">					
				<div class="col-md-12">
					<div class="clients-logo-slider">
						<div class="owl-carousel clients-slider">
						    <div class="item">
							  <a href="#"><img src="images/client/tatwa.jpg" alt="slide 1" class=""></a>	
							</div>  
							<div class="item">
							  <a href="#"><img src="images/client/C1.jpg" alt="slide 1" class=""></a>	
							</div>
							<div class="item">
							  <a href="#"><img src="images/client/C3.jpg" alt="slide 1" class=""></a>	
							</div>
							<div class="item">
							  <a href="#"><img src="images/client/C4.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C5.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C6.jpg" alt="slide 1" class=""></a>
							</div>  
							<div class="item">
							  <a href="#"><img src="images/client/C7.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C9.jpg" alt="slide 1" class=""></a>
							</div>      
							<div class="item">
							  <a href="#"><img src="images/client/C10.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C11.jpg" alt="slide 1" class=""></a>
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C12.jpg" alt="slide 1" class=""></a>	
							</div>               
							<div class="item">
							  <a href="#"><img src="images/client/cognis.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/Netpro.jpg" alt="slide 1" class=""></a>
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/rubic.jpg" alt="slide 1" class=""></a>	
							</div>               
						</div>	
					</div>									
				</div>		
			</div>		
		</div>
	</div>       
   
    <div class="padding-top-large"></div>
      
	  <?php include_once('footer.php'); ?>   
	