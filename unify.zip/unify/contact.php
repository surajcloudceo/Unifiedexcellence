<?php include_once('header.php'); ?>


      
	<div class="business-banner">           			
        <div class="hvrbox">
            <img src="images/contact-us.jpg" alt="Contact" class="hvrbox-layer_bottom">
            <div class="hvrbox-layer_top">
                <div class="container">
                    <div class="overlay-text text-left">						
                       <!-- <h3>Contact Us</h3>-->
                        <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                          </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>	                     
    </div>      

    <div class="padding-top-large"></div>
      
    <div class="bussiness-our-address">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-address text-center">
                        <i class="fa fa-map-marker"></i>
                        <h4>India Office(Corporate Office)</h4>
                            <!--<p>15-14-523/524,PH-1, R K ESTATES B BL KPHB COLONY, ROAD NO 2 Kukatpally,Hyderabad,Telangana, 500072, India.</p>
                            <p> #404, </br>Ashok Vihar,</br>Suncity,Bandlaguda Jagir,</br>Hyderabad, 500086 </br> Telangana ,India.</p>-->	 
				        	<p>  #404, Ashok Vihar,<br />Suncity,Bandlaguda Jagir,</br>Hyderabad, 500086 </br> Telangana ,India.</p>	
							       <!--<p>LLP Identification Number:-AAJ-1253</p>    -->     
                    </div>   
					
                </div>
                <div class="col-md-4">
                    <div class="single-address text-center">
                        <i class="fa fa-phone"></i>
                        <h4>Contact Us</h4>
                        <p> Office: +91-9603991485 <br>
						    
                        </p>             
                    </div>   
                </div>
                <div class="col-md-4">
                    <div class="single-address text-center">
                        <i class="fa fa-location-arrow"></i>
                        <h4>Write Some Words</h4>
                        <p> info@unifiedexcellence.com <br>
                            unifiedexcellence@gmail.com <br>
                        </p> 
                    </div>   
                </div>   
            </div>   
			<!--<div class="row">
                <div class="col-md-4">
                    <div class="single-address text-center">
                       
                        <h4>USA</h4>
                                   
                    </div>   
                </div>
                <div class="col-md-4">
                    <div class="single-address text-center">
                       
                        <h4>Contact Us</h4>
                       
                        </p>                  
                    </div>   
                </div>
                <div class="col-md-4">
                    <div class="single-address text-center">
                        
                        <h4>Write Some Words</h4>
                        <p> info@unifiedexcellence.com <br>
                        
                        </p>                   
                    </div>   
                </div>   
            </div>-->
        </div>   
    </div>
      
    <div class="padding-top-large"></div>
      
     <!--<div class="bussiness-contact-form">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="business-title-left">
                        <h2>Feedback form</h2>
                        <span class="title-border-left"></span>
                        <p>We love to hear from you. Fill up the form below and we will get back to you as soon as possible.<br> Have partners in all major countries all over the globe.</p>
                    </div>
                    
                </div>
 
                    
                       
                <div class="col-md-6">                        
                  <div class="form-group">                        
                    <input type="text" class="form-control" id="formGroupExampleInput1" placeholder="Your First Name">
                  </div>
                </div>
                <div class="col-md-6">                        
                  <div class="form-group">
                    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Your last Name">
                  </div>
                </div>
                <div class="col-md-6">                        
                  <div class="form-group">
                    <input type="email" class="form-control" id="formGroupExampleInput3" placeholder="Your Email">
                  </div>
                </div>
                <div class="col-md-6">                        
                  <div class="form-group">
                    <input type="number" class="form-control" id="formGroupExampleInput4" placeholder="Phone Number">
                  </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                      <textarea class="form-control" id="exampleFormControlTextarea15" rows="3" placeholder="Your Message"></textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                      <a href="#" class="btn bussiness-btn-larg">Send Message</a>
                    </div>
                </div>
                       
                    
    
            </div>
        </div>
    </div>-->
      
	  
	   <section>
        <div id="csi-contact" class="csi-contact">
            <div class="csi-inner" style="    padding:0rem 0 5em 0;">
                <div class="container">
                    <div class="row">
					<div class="col-sm-4" style="color:#000;">
					<h3 class="title"> Website </h3>
						<address>
						   www.unifiedexcellence.com
						</address>
									
						<address>
							<h3 class="title"> Email</h3>
							sales@unifiedexcellence.com <br> support@unifiedexcellence.com
						</address>
						
						
						<div>
							<h3 class="title">Our Timings</h3>
							
							<p class="text">
								 10:00 AM - 21:00 PM (Monday - Saturday) <br />
							     12:00 PM - 06:00 PM (Sunday)
							</p>
							
						</div>
					</div>
               <div class="col-sm-8">
			    <div class="business-title-middle">
							<h2>Business Enquiry</h2>
							<span class="title-border-middle"></span>
						</div>
                 <p id="errmsg"></p>
                <form name="contact-form" method="post" action="">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">
                                Name</label>
                            <input type="text" class="form-control" name="mname" id="mname" placeholder="Enter Name" required="required" />
                        </div>
                        <div class="form-group">
                            <label for="email">
                                Email Address</label>
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                </span>
                                <input type="email" class="form-control" name="memail" id="memail" placeholder="Enter email" required="required" /></div>
                        </div>
						<div class="form-group">
                            <label for="phone">
                                Phone Number</label> <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span>
                                </span>
                            <input type="text" class="form-control" name="mphone" id="mphone" placeholder="Enter Mobile Number" required="required" /></div>
                        </div>
                        <div class="form-group">
                            <label for="subject">
                                Subject</label>
                            <select id="msubject" name="msubject" class="form-control" required="required">
                                <option value="na" selected="">---Choose One---</option>
                                <option value="information">General Information</option>
								<option value="enquiry">General Enquiry</option>
                                <option value="service">Customer Service</option>
                            </select>
                        </div>
						
                    </div>
                    <div class="col-md-6">
					
					     <div class="form-group">
                            <label for="subject">
                                Refer</label>
                            <select id="mrefer" name="mrefer" class="form-control" required="required">
                                <option value="na" selected="">---Choose One---</option>
                                <option value="facebook">Facebook</option>
                                <option value="twitter">Twitter</option>
                                <option value="GetApp">GetApp</option>
								<option value="Search Engine">Search Engine</option>
                                <option value="Social Media">Social Media</option>
                                <option value="Advertisement">Advertisement</option>
								<option value="Event">Event</option>
                                <option value="Forum/Blog">Forum/Blog</option>
								<option value="Other">Other</option>
                            </select>
                        </div>
						
                        <div class="form-group">
                            <label for="message">
                                Message</label>
                            <textarea name="message" id="message" class="form-control" rows="10" cols="25" required="required"
                                placeholder="Message"></textarea>
                        </div>
                    </div>
					
					
                    <div class="col-md-12">
                        <!--<button type="submit" class="btn btn-primary pull-right" id="btnContactUs">Send Message</button>-->
						<button type="button" onClick="sendmail()" value="submit" class="btn bussiness-btn-larg pull-right">Send Message</button>
                            
                    </div>
                </div>
                </form>
                            <!-- MODAL SECTION -->
                            <div id="csi-form-modal" class="modal fade csi-form-modal" tabindex="-1" role="dialog" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content csi-modal-content">
                                        <div class="modal-header csi-modal-header">
                                            <button type="button" class="close brand-color-hover" data-dismiss="modal" aria-label="Close">
                                                <i class="fa fa-power-off"></i>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert csi-form-msg" role="alert"></div>
                                        </div> <!--//MODAL BODY-->
                                    </div>
                                </div>
                            </div> <!-- //MODAL -->
                        </div> <!--//.COL-->
                    </div>
                </div><!-- //.CONTAINER -->
            </div><!-- //.INNER -->
        </div>
    </section>
	
      
    <div class="padding-top-large"></div>
      
	<!-- Start Client Map -->
	<!--<div class="client_map">
		<div class="row">
			<div id="map"></div>
		</div>
	</div>-->
	<!-- End Client Map -->	
	    
 <?php include_once('footer.php'); ?>
     
	<script type="text/javascript">
			 function sendmail() { 
			 $mname = $('#mname').val();
			 $memail = $('#memail').val();
			 $mphone = $('#mphone').val();
			 $msubject = $('#msubject').val();
			 $mrefer = $('#mrefer').val();
			 $message = $('#message').val();
			if($mname == ''){ document.getElementById("errmsg").innerHTML='Enter Name'; return false; }
			if($memail == ''){ document.getElementById("errmsg").innerHTML='Enter Email'; return false; }
			if($mphone == ''){ document.getElementById("errmsg").innerHTML='Enter Mobile'; return false; }
			if($msubject == ''){ document.getElementById("errmsg").innerHTML='Enter Subject'; return false; }
			if($mrefer == ''){ document.getElementById("errmsg").innerHTML='Enter Refer By'; return false; }
			if($message == ''){ document.getElementById("errmsg").innerHTML='Enter Message'; return false; }
			
			$.ajax({
				type: "POST",
				url: "config.php",
				data:'mname='+$mname+'&memail='+$memail+'&mphone='+$mphone+'&msubject='+$msubject+'&mrefer='+$mrefer+'&message='+$message,
				beforeSend: function(){
					document.getElementById("errmsg").innerHTML='Email is sending...';
				},
				success: function(data){
					document.getElementById("errmsg").innerHTML=data;
				}
			});
	       return false;
		}
		
		

    </script>