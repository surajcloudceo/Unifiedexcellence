<!-- Start Footer -->
	<footer class="bussiness-footer-1x">		
		  <div class="bussiness-footer-content ">
				<div class="container">
					<div class="row">
						<div class="col-md-3">	
							<div class="bussiness-footer-address">	
								<a href="https://www.unifiedexcellence.com/images/ISO.jpg"><img src="images/ISO.jpg" alt="Logo"></a><br>
								
								   							
									
									<!--<p> <i class="fa fa-map-marker"></i>  Suite #401, <br />Manjeera Majestic <br /> Commercial Complex,<br /> Kukatpally, Hyderabad, Telangana 500072,India.</p>	        			-->							
							</div>
						</div>
						<div class="col-md-3">
							<h5> Services </h5>
							<ul>
								<li><a  href="softwaredevelopment">Software Development</a></li>
								<li><a  href="consultingservice">Consulting Services</a></li>
								<li><a  href="hospitalityservice">Hospitality Services</a></li>
								<li><a  href="amcservice">Computer AMC Services</a></li>
								<li><a  href="banking">Banking & Finance</a></li>
								<li><a  href="multimedia-ad">Multimedia & Advertising</a></li>
							</ul>
						</div>							
						<div class="col-md-3">	
							<h5> Useful Links </h5>
							<ul>
								<li><a href="aboutus"> About Unified Excellence </a></li>				
								<li><a href="projects"> Projects </a></li>				
								<li><a href="career"> Career </a></li>
                                                                <li><a href="contact"> Contact </a></li>
<li><a href="https://www.unifiedexcellence.com/images/client/uprofile.pdf" target="_blank"> Our Profile </a></li>

								
							</ul>			
						</div>

						<div class="col-md-3">	
							<h5>Awards and Achievements</h5>
								<p>Our Professionals and Technical Experts are always committed to exploring new strategy by using latest technology and complete the mechanism in a stipulated time given by the Client.</p>
													
						</div>					
 
                        <div class="container">	
                            <div class="">
                                <div class="col-md-12 footer-info">
                                    <div class="row">	
                                        <div class="col-md-6">	
                                            <div class="footer-info-left">	
                                                <p>By using this site you agree that we can place cookies on your device. See our Privacy Policy and Cookie Policy for details.<br />@ 2018 <a href="http://www.unifiedexcellence.com/">Unified Excellence LLP,</a> All Rights Reserved.</p>
                                            </div>			
                                        </div>			
                                        <div class="col-md-6">
                                            <div class="footer-info-right">
                                                <ul>
                                                    <li><a href="https://en-gb.facebook.com/people/Unified-Excellence/100016618418817"> <i class="fa fa-facebook" style="color:#3a5799"></i> </a></li>										
                                                    <li><a href="https://twitter.com/unifiedexcgroup?lang=en"> <i class="fa fa-twitter" style="color:#02baf6"></i> </a></li>											
                                                  								
                                                </ul>					
                                            </div>					
                                        </div>					
                                    </div>					
                                </div>					
                            </div>	  
						</div>
				
					</div>					
				</div>			
		  </div>		  
	</footer>	
	<!-- End Footer -->		     
    
   	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<!-- Wow Script -->
	<script src="js/wow.min.js"></script>
	<!-- Counter Script -->
	<script src="js/waypoints.min.js"></script>
	<script src="js/jquery.counterup.min.js"></script>
	<!-- Masonry Portfolio Script -->
    <script src="js/jquery.filterizr.min.js"></script>
    <script src="js/filterizer-controls.js"></script>
    <!-- OWL Carousel js-->
	<script src="js/owl.carousel.min.js"></script>  
	<!-- Lightbox js -->
	<script src="inc/lightbox/js/jquery.fancybox.pack.js"></script>
	<script src="inc/lightbox/js/lightbox.js"></script>
	<!-- Google map js -->
	<script  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCa6w23do1qZsmF1Xo3atuFzzMYadTuTu0"></script>	
	<script src="js/map.js"></script>
	<!-- loader js-->
    <script src="js/fakeLoader.min.js"></script>
	<!-- Scroll bottom to top -->
	<script src="js/scrolltopcontrol.js"></script>
	<!-- menu -->
	<script src="js/bootstrap-4-navbar.js"></script>    
    <!-- Stiky menu -->
	<script src="js/jquery.sticky.js"></script>  
    <!-- youtube popup video -->
	<script src="js/jquery.magnific-popup.min.js"></script>  
	<!-- Custom script -->
    <script src="js/custom.js"></script>
  </body>
</html>     