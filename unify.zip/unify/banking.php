<?php include_once('header.php'); ?>
     
	<div class="business-banner">           			
        <div class="hvrbox">
            <img src="images/banner-top.jpeg" alt="Mountains" class="hvrbox-layer_bottom">
            <div class="hvrbox-layer_top">
                <div class="container">
                    <div class="overlay-text text-left">						
                        <h3>Banking & Finance</h3>
                        <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Banking & Finance</li>
                          </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>	                     
    </div>      
 		
    <div class="bussiness-about-company">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                     <div class="padding-top-large"></div>
                    
                    <div class="about-company-left">
						 <p> To carry on the business of providing financial consultancy services and exchange of research and analysis.</p>                     
                            <p> To work as advisors and consultants and to provide services for project syndication, project loan syndication, structured debt syndication, debt restructuring, mutual funds, banks, financial institutions, insurance companies and private sector funds. to provide consultancy for efficient execution, quality research and high degree of compliance in primary & secondary markets. it provide investment advisory in various products including govt. securities, treasury bills, bonds and debentures, state guaranteed papers and commercial papers.

 </p>
                            <div class="promotion-box">		
							<p> MANAGEMENT & FINANCIAL CONSULTANCY</p>					
							<p>Advisors and Consultants to provide services for project syndication and loan syndication from banks and financial institutions. Help businesses improve their performance and grow by solving problems and finding new and better ways of doing things.</p>
						   </div> 
                          <p>To carry on the business of providing consultancy or advisory  services related to project finance and personal finance, loan syndication, to act as marketing agents of banks, financial institution and  Financial service providers.</p>
                       </div>
                    
                    
                    
                    
                </div>
                <div class="col-md-3">
                    <div class="padding-top-large"></div>
                    <div class="about-company-right">
                        <div class="right-menubar">
                            <ul>
							  <li class=""><a href="softwaredevelopment.php">Software Development</a></li>
                                <li class=""><a href="consultingservice.php">Consulting Services</a></li>
                                <li><a href="hospitalityservice.php">Hospitality Services</a></li>
                                <li><a href="amcservice.php">Computer AMC Services</a></li>
                                <li class="active"><a href="banking.php">Banking & Finance</a></li>
                                <li><a href="multimedia-ad.php">Multimedia & Advertising</a></li>
                            </ul>
                        </div>                        
                        
                        <div class="padding-top-middle"></div>
                        
                        
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
 
    <div class="padding-top-large"></div>
      
  
      
    <div class="business-cta-2x">
		<div class="business-cta-2-content">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<div class="business-cta-left-2">
							<h2>Looking for an excelent business solution ? Your business will change forever with our innovative.</h2>
						</div>
					</div>	
					<div class="col-md-4">
						<div class="business-cta-right-2">
							<a href="contact.php" class=" btn bussiness-btn-larg">Get a Quote <i class="fa fa-angle-right"></i> </a>
						</div>
					</div>	
				</div>	
			</div>	
		</div>	
	</div>
      
	<div class="padding-top-large"></div>
      
    <div class="clients-slider-1x">	
		<div class="container">
			<div class="row">					
				<div class="col-md-12">
					<div class="clients-logo-slider">
						<div class="owl-carousel clients-slider">
						    <div class="item">
							  <a href="#"><img src="images/client/tatwa.jpg" alt="slide 1" class=""></a>	
							</div>  
							<div class="item">
							  <a href="#"><img src="images/client/C1.jpg" alt="slide 1" class=""></a>	
							</div>
							<div class="item">
							  <a href="#"><img src="images/client/C3.jpg" alt="slide 1" class=""></a>	
							</div>
							<div class="item">
							  <a href="#"><img src="images/client/C4.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C5.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C6.jpg" alt="slide 1" class=""></a>
							</div>  
							<div class="item">
							  <a href="#"><img src="images/client/C7.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C9.jpg" alt="slide 1" class=""></a>
							</div>      
							<div class="item">
							  <a href="#"><img src="images/client/C10.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C11.jpg" alt="slide 1" class=""></a>
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C12.jpg" alt="slide 1" class=""></a>	
							</div>               
							<div class="item">
							  <a href="#"><img src="images/client/cognis.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/Netpro.jpg" alt="slide 1" class=""></a>
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/rubic.jpg" alt="slide 1" class=""></a>	
							</div>               
						</div>	
					</div>									
				</div>		
			</div>		
		</div>
	</div>       
   
    <div class="padding-top-large"></div>
      
	  <?php include_once('footer.php'); ?>   
	