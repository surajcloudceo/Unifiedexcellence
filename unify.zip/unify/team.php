<?php include_once('header.php'); ?>

      
	<div class="business-banner">           			
        <div class="hvrbox">
            <img src="images/services-banner.jpg" alt="Mountains" class="hvrbox-layer_bottom">
            <div class="hvrbox-layer_top">
                <div class="container">
                    <div class="overlay-text text-left">						
                        <h3>Our Management Team</h3>
                        <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Our Management Team</li>
                          </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>	                     
    </div>      
 	<div class="padding-top-large"></div>
	<div class="team-members-1x">	
        <div class="container">
            <div class="team-members-content">
                <div class="row">

                    <div class="col-md-4">
                        <div class="business-title-left">
                            <h2>Team Members</h2>
                            <span class="title-border-left"></span>
                        </div>
                        <div class="team-members-left">
                            <!--<p>The advantages to having Unified Excellence as a Software and System Development Partner Unified Excellence executing it's all projects based on Agile Methodologies and DevOps.</p>	-->						
                           <!-- <a href="#" class="bussiness-btn-larg">See Our Team</a>	-->					
                        </div>
                    </div>

                    <div class="col-md-8">
						<div class="row">					
							<div class="col-md-12">
								<div class="team-members-right">
									<div class="owl-carousel team-members">
										<div class="item hover01">
										  <!--<figure><img src="images/member/nouser.png" alt="slide 1" class=""></figure>-->										 
										  <a href="#">Mr. ChanchiriBabu</a>										  
										  <h3>Founder, Managing Director</h3>										  
										</div> 
										<div class="item hover01">
										  <!--<figure><img src="images/member/nouser.png" alt="slide 1" class=""></figure>	-->									 
										  <a href="#">Smt. D Sirisha</a>										  
										  <h3>Founder, Executive Director</h3>										  
										</div> 
										<!--<div class="item hover01">
										  <!--<figure><img src="images/member/nouser.png" alt="slide 1" class=""></figure>									 
										  <a href="#">Suraj Samantara</a>										  
										  <h3>Co-Founder, Strategy & Operations</h3>										  
										</div>--> 
										
										<div class="item hover01">
										  <!--<figure><img src="images/member/team-member-3.jpg" alt="slide 1" class=""></figure>-->										 
										  <a href="#"> </a>										  
										  <h3>Chief Operating Officer(COO) </h3>										  
										</div> 
										          
									</div>	
								</div>									
							</div>		
						</div>		
					</div>		

                </div>
            </div>
        </div>
    </div>
      
      
	<div class="padding-top-large"></div>
      
    

      
 <?php include_once('footer.php'); ?>   