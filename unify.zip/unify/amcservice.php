<?php include_once('header.php'); ?>
     
	<div class="business-banner">           			
        <div class="hvrbox">
            <img src="images/banner-top.jpg" alt="Mountains" class="hvrbox-layer_bottom">
            <div class="hvrbox-layer_top">
                <div class="container">
                    <div class="overlay-text text-left">						
                        <h3>Computer AMC Services</h3>
                        <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Computer AMC Services</li>
                          </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>	                     
    </div>      
 		
    <div class="bussiness-about-company">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                     <div class="padding-top-large"></div>
                    
                    <div class="about-company-left">
						 <p> To carry on the business of Annual maintenance contract for your computers.We are attached with different companies and our services has been outstanding so far. We have been maintaining the hardware and network of big corporate, Small Scale Industries,small organizations and government undertaking. We blend our qualitative service with the latest technology to offer our customers a competitive edge at effective price.We are effectively exploring the latest hardware available in the market to provide Computer AMC Services for the betterment of the life of your Computers. We can assemble the whole systems according to the configuration you give us.</p>                     
                            <p>AMC for software services is one of the major hurdles in Industry. Either there will not be enough resources from supplied vendor to give support to application or their support charges may exceed your allocated budgets. We at Ziel Infosolutions give most prominence for existing customers as well as software. We allocates resources exclusively for AMC support as the running application maintenance is a crucial part in Industry. Well experienced, practically knowledgeable resources will resolve your issue within stipulated time frame. </p>
                            <div class="promotion-box">	
							<p>AMC of Computer and Networking</p>						
							<p>It checks to ensure smooth functioning of machines. For each machine aoss maintains a seperate machine job-card to ensure close monitoring and control.</p>
			 </div> 
                           <p>Software provide services from 9 A.M to 9 P.M for sophisticated installation like hotel,Banks,Hospitals & Corporates. </p>
                       </div>
                    
                  
                </div>
                <div class="col-md-3">
                    <div class="padding-top-large"></div>
                    <div class="about-company-right">
                        <div class="right-menubar">
                            <ul>
							  <li class=""><a href="softwaredevelopment.php">Software Development</a></li>
                                <li class=""><a href="consultingservice.php">Consulting Services</a></li>
                                <li class=""><a href="hospitalityservice.php">Hospitality Services</a></li>
                                <li class="active"><a href="amcservice.php">Computer AMC Services</a></li>
                                <li><a href="banking.php">Banking & Finance</a></li>
                                <li><a href="multimedia-ad.php">Multimedia & Advertising</a></li>
                            </ul>
                        </div>                        
                        
                        <div class="padding-top-middle"></div>
                        
                     
                     
                    </div>
                </div>
            </div>
        </div>
    </div>
 
    <div class="padding-top-large"></div>
      
  
      
    <div class="business-cta-2x">
		<div class="business-cta-2-content">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<div class="business-cta-left-2">
							<h2>Looking for an excelent business solution ? Your business will change forever with our innovative.</h2>
						</div>
					</div>	
					<div class="col-md-4">
						<div class="business-cta-right-2">
							<a href="contact.php" class=" btn bussiness-btn-larg">Get a Quote <i class="fa fa-angle-right"></i> </a>
						</div>
					</div>	
				</div>	
			</div>	
		</div>	
	</div>
      
	<div class="padding-top-large"></div>
      
    <div class="clients-slider-1x">	
		<div class="container">
			<div class="row">					
				<div class="col-md-12">
					<div class="clients-logo-slider">
						<div class="owl-carousel clients-slider">
						    <div class="item">
							  <a href="#"><img src="images/client/tatwa.jpg" alt="slide 1" class=""></a>	
							</div>  
							<div class="item">
							  <a href="#"><img src="images/client/C1.jpg" alt="slide 1" class=""></a>	
							</div>
							<div class="item">
							  <a href="#"><img src="images/client/C3.jpg" alt="slide 1" class=""></a>	
							</div>
							<div class="item">
							  <a href="#"><img src="images/client/C4.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C5.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C6.jpg" alt="slide 1" class=""></a>
							</div>  
							<div class="item">
							  <a href="#"><img src="images/client/C7.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C9.jpg" alt="slide 1" class=""></a>
							</div>      
							<div class="item">
							  <a href="#"><img src="images/client/C10.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C11.jpg" alt="slide 1" class=""></a>
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/C12.jpg" alt="slide 1" class=""></a>	
							</div>               
							<div class="item">
							  <a href="#"><img src="images/client/cognis.jpg" alt="slide 1" class=""></a>	
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/Netpro.jpg" alt="slide 1" class=""></a>
							</div> 
							<div class="item">
							  <a href="#"><img src="images/client/rubic.jpg" alt="slide 1" class=""></a>	
							</div>               
						</div>	
					</div>									
				</div>		
			</div>		
		</div>
	</div>       
   
    <div class="padding-top-large"></div>
      
	  <?php include_once('footer.php'); ?>   
	